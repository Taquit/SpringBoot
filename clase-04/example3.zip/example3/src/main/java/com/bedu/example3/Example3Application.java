package com.bedu.example3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Example3Application {

	public static void main(String[] args) {
		SpringApplication.run(Example3Application.class, args);
	}

}
