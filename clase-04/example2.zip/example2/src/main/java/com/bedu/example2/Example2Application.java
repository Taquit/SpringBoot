package com.bedu.example2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Example2Application {

	public static void main(String[] args) {
		SpringApplication.run(Example2Application.class, args);
	}

}
